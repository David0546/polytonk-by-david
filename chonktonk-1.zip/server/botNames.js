exports.botNames = ["𝕾𝖔𝖒𝖊𝕿𝖎𝖒𝖊𝖘", "๖ۣۜǤнσsт", "★F|r|a|n|k|l|i|n★", "🐺꧁⚔ℓσвiท", "- yτ⚔꧂🐺", "Pℝiⱥticђic", "༄ᶦᶰᵈ᭄✿Gᴀᴍᴇʀ࿐", "『SRG』×͜×  ᴋɪʟʟᴇʀ࿐", "꧁༒ .TiK Tok. ༒꧂", "꧁ᏢᎡϟꋊᏣᎬᏕㅤ亗꧂", "ツ", "( ͡° ͜ʖ ͡°)", "Korexk", "Fume", "ƤℜɆĐ₳₮Øℜ", "༒ֆนPeℝ۞", "亗", "メ", "亗『LEGEND』亗"];
exports.getBotName = function() {
  return exports.botNames[Math.floor(Math.random() * exports.botNames.length)];
};